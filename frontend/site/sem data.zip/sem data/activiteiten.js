const activities = [
    {   
        image: "45.jpg",
        alt: "Activiteiten",
        title: "Activiteiten",
        text: "In juli en augustus hebben we een gevarieerd aanbod voor alle leeftijden. De meeste activiteiten zijn gratis en zonder aanmelding vooraf. Knutselpakketjes zijn verkrijgbaar bij de supermarkt. Kies de creatieve, sportieve of Do It Yourself activiteit die bij jou past!",
    },

    {
        image: "46.jpg",
        alt: "Live sportuitzendingen",
        title: "Live sportuitzendingen",
        text: "Sportfans opgelet! Op ons park beleef je nu alle sportieve hoogtepunten van het jaar onder het genot van een hapje en drankje. Of je nu een groot liefhebber van de Tour bent en de Olympische Spelen op de voet volgt, als superfan van Les Bleus op te bank staat te springen of luidkeels juicht voor de Formule 1: jij hoeft geen wedstrijd te missen. Alle belangrijke sportwedstrijden voor Nederlandse sporters en teams kijk je tijdens de live uitzendingen in onze horeca.",
    }
];

function activiteiten(){
    return activities;
}
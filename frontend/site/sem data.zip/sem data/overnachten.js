const bookings = [
    {   
        image: "2.jpg",
        alt: "Comfort",
        title: "Comfort",
        text: "some text",
        points: "<a>Some text</a></li><li><a>Some text</a>",
        price: "40,-",
        images: "2.jpg,39.jpg,3.jpg,38.jpg,40.jpg,9.jpg"
    },

    {
        image: "41.jpg",
        alt: "Royal",
        title: "Royal",
        text: "some text",
        points: "<a>Some text</a></li><li><a>Some text</a>",
        price: "43,-",
        images: "41.jpg,13.jpg,3.jpg,12.jpg"
    },

    {
        image: "37.jpg",
        alt: "RoyalCamper",
        title: "Royal Camper",
        text: "some text",
        points: "<a>Some text</a></li><li><a>Some text</a>",
        price: "43,-",
        images: "37.jpg,38.jpg,12.jpg,13.jpg"
    }
];

function overnachten(){
    return bookings;
}